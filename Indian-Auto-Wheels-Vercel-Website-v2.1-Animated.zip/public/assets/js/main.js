document.documentElement.classList.add('has-js');
document.addEventListener('DOMContentLoaded',()=>{
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const b=document.querySelector('.menu-toggle'),n=document.querySelector('.site-nav');
  const closeMenu=()=>{if(!b||!n)return;n.classList.remove('open');b.classList.remove('is-open');b.setAttribute('aria-expanded','false')};
  if(b&&n){
    b.addEventListener('click',()=>{const open=n.classList.toggle('open');b.classList.toggle('is-open',open);b.setAttribute('aria-expanded',open?'true':'false')});
    n.querySelectorAll('a').forEach(link=>link.addEventListener('click',closeMenu));
    document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});
  }

  const header=document.querySelector('.site-header'),progress=document.querySelector('.scroll-progress');
  const onScroll=()=>{const top=window.scrollY,max=document.documentElement.scrollHeight-window.innerHeight;header?.classList.toggle('is-scrolled',top>30);if(progress)progress.style.transform=`scaleX(${max>0?top/max:0})`};
  onScroll();window.addEventListener('scroll',onScroll,{passive:true});

  const slider=document.querySelector('[data-hero-slider]');
  if(slider&&!slider.classList.contains('has-video')){
    const slides=[...slider.querySelectorAll('.hero-slide')],panels=[...slider.querySelectorAll('[data-hero-panel]')],dots=[...slider.querySelectorAll('.hero-dots button')];let active=0,timer,touchStart=0;
    const show=i=>{active=(i+slides.length)%slides.length;slides.forEach((slide,index)=>{const current=index===active;slide.classList.toggle('is-active',current);slide.setAttribute('aria-hidden',current?'false':'true')});panels.forEach((panel,index)=>{const current=index===active;panel.classList.toggle('is-active',current);panel.setAttribute('aria-hidden',current?'false':'true')});dots.forEach((dot,index)=>{const current=index===active;dot.classList.toggle('is-active',current);dot.setAttribute('aria-current',current?'true':'false')})};
    const start=()=>{window.clearInterval(timer);if(!reduced&&slides.length>1)timer=window.setInterval(()=>show(active+1),3500)};
    dots.forEach((dot,index)=>dot.addEventListener('click',()=>{show(index);start()}));
    slider.addEventListener('mouseenter',()=>window.clearInterval(timer));slider.addEventListener('mouseleave',start);
    slider.addEventListener('touchstart',e=>{touchStart=e.changedTouches[0].clientX},{passive:true});slider.addEventListener('touchend',e=>{const distance=e.changedTouches[0].clientX-touchStart;if(Math.abs(distance)>45){show(active+(distance<0?1:-1));start()}},{passive:true});
    document.addEventListener('visibilitychange',()=>document.hidden?window.clearInterval(timer):start());show(0);start();
  }

  const revealTargets=document.querySelectorAll('.section>.container,.service-image,.service-copy,.page-hero>.container,.static-content>.container>*,.static-grid>.static-card,.static-contact-details>*,.static-form,.content-area article,.business-link-grid>a,.info-grid article,.trust-grid article,.capability-pro-grid article,.quality-photo,.quality-content,.delivery-process article,.process-visual-track article,.project-gallery article,.branch-cards article,.confidence-list article,.quote-form,.career-intro-grid,.career-benefit-grid article,.opening-card,.career-profile-grid,.career-application-form,.career-hr,.career-process li');
  revealTargets.forEach((el,index)=>{el.classList.add('reveal-item');el.style.setProperty('--reveal-delay',`${(index%4)*65}ms`)});
  if('IntersectionObserver'in window&&!reduced){
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-visible');observer.unobserve(entry.target)}}),{threshold:.12,rootMargin:'0px 0px -45px'});
    revealTargets.forEach(el=>observer.observe(el));
  }else revealTargets.forEach(el=>el.classList.add('is-visible'));

  // A restrained depth effect keeps the large banners feeling alive without
  // affecting page layout or touch performance.
  if(!reduced&&window.matchMedia('(min-width: 901px)').matches){
    const depthTargets=[...document.querySelectorAll('.page-hero'),document.querySelector('.hero-watermark')].filter(Boolean);
    let depthFrame=0;
    const updateDepth=()=>{const y=Math.min(window.scrollY,720);depthTargets.forEach((el,index)=>el.style.setProperty('--scroll-depth',`${y*(index ? .055 : .075)}px`));depthFrame=0};
    window.addEventListener('scroll',()=>{if(!depthFrame)depthFrame=requestAnimationFrame(updateDepth)},{passive:true});
    updateDepth();
  }

  const counters=document.querySelectorAll('[data-count]');
  const runCounter=el=>{const end=Number(el.dataset.count)||0,start=performance.now(),duration=1100;const tick=now=>{const p=Math.min((now-start)/duration,1),ease=1-Math.pow(1-p,3);el.textContent=Math.round(end*ease)+(end===7?'+':'');if(p<1)requestAnimationFrame(tick)};requestAnimationFrame(tick)};
  if('IntersectionObserver'in window&&!reduced){const counterObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){runCounter(entry.target);counterObserver.unobserve(entry.target)}}),{threshold:.8});counters.forEach(el=>counterObserver.observe(el))}else counters.forEach(el=>{el.textContent=el.dataset.count+(el.dataset.count==='7'?'+':'')});

  const filterButtons=[...document.querySelectorAll('[data-filter]')],projects=[...document.querySelectorAll('[data-project]')];
  filterButtons.forEach(button=>button.addEventListener('click',()=>{const filter=button.dataset.filter;filterButtons.forEach(item=>item.classList.toggle('is-active',item===button));projects.forEach(project=>{const visible=filter==='all'||project.dataset.project===filter;project.classList.toggle('is-filtered-out',!visible);project.setAttribute('aria-hidden',visible?'false':'true')})}));

  document.querySelectorAll('[data-quote-product]').forEach(link=>link.addEventListener('click',()=>{const field=document.querySelector('#quote-body');if(field){field.value=link.dataset.quoteProduct;window.setTimeout(()=>field.focus(),450)}}));

  document.querySelectorAll('[data-career-position]').forEach(link=>link.addEventListener('click',()=>{const field=document.querySelector('#career-position');if(field){field.value=link.dataset.careerPosition;window.setTimeout(()=>field.focus(),450)}}));

  const quote=document.querySelector('#iaw-smart-quote');
  if(quote)quote.addEventListener('submit',e=>{e.preventDefault();const q=id=>quote.querySelector(id)?.value||'Not specified';const lines=['Hello Indian Auto Wheels,','I would like to request a quotation.','','Name: '+q('#quote-name'),'Mobile: '+q('#quote-mobile'),'Vehicle Type: '+q('#quote-vehicle'),'Application: '+q('#quote-application'),'Expected Payload: '+q('#quote-payload'),'Body Configuration: '+q('#quote-body'),'Quantity: '+q('#quote-quantity'),'Preferred Location: '+q('#quote-location'),'Additional Requirement: '+q('#quote-message')];window.open('https://wa.me/'+quote.querySelector('button').dataset.mobile+'?text='+encodeURIComponent(lines.join('\n')),'_blank')});

  const f=document.querySelector('#iaw-enquiry');
  if(f)f.addEventListener('submit',e=>{e.preventDefault();const q=id=>document.querySelector(id)?.value||'';const lines=['Hello Indian Auto Wheels,','Name: '+q('#iaw-name'),'Mobile: '+q('#iaw-phone'),'Email: '+q('#iaw-email'),'City: '+q('#iaw-city'),'Requirement: '+q('#iaw-need'),'Vehicle or Product: '+q('#iaw-product'),'Message: '+q('#iaw-message')];window.open('https://wa.me/'+f.querySelector('button').dataset.mobile+'?text='+encodeURIComponent(lines.join('\n')),'_blank')});
});
