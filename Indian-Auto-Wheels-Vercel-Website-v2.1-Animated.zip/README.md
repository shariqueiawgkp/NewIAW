# Indian Auto Wheels — Professional Vercel Website 2.0

This is the Vercel-compatible version of the previous Indian Auto Wheels professional design. It is a static Node build and does not require WordPress, PHP or MySQL.

## Easy editing — visual method

1. Double-click `EDIT-WEBSITE.html`.
2. Select the project’s `site.config.json` file.
3. Change the required fields.
4. Click **Download Updated site.config.json**.
5. Replace the old `site.config.json` with the downloaded file.
6. Run `npm run build`, then commit/push the changes to GitHub. Vercel deploys the update automatically.

## Easy editing — direct method

Open `site.config.json` to change the phone number, WhatsApp number, email, address, branch locations, homepage slides, main page headings and career openings. Replace images inside `public/assets/images/` while keeping the same filename, or change the image path in `site.config.json`.

Design changes are in `public/assets/css/static.css`. The original theme styling is preserved in `public/assets/css/style.css`.

## Deploy on Vercel

### GitHub method

1. Extract this ZIP.
2. Upload the complete `iaw-vercel-website` folder to a GitHub repository.
3. In Vercel choose **Add New → Project**.
4. Import the GitHub repository.
5. Vercel will automatically use `npm run build` and the `dist` output folder.
6. Click **Deploy**.

### Vercel CLI method

Run these commands inside the project folder:

```bash
npm install
npm run build
npx vercel
```

## Local preview

```bash
npm run build
npx serve dist
```

## Pages included

- Home
- About Us
- MD Message
- Director Message
- History
- Mission and Vision
- Business
- Manufacturing
- News Room
- Career
- Contact Us

The HCV, LCV and CASE submenu items link to their official websites. There is no separate Products page.
